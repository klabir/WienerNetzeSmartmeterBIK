# Contributors

## Special thanks for all the people who had helped this project so far and spent their valuable time on this matter

### Active contributors
* [DarwinsBuddy](https://github.com/DarwinsBuddy)
* [reox](https://github.com/reox)
* [TheRealVira](https://github.com/TheRealVira)
* [tschoerk](https://github.com/tschoerk)
* [W-M-B](https://github.com/W-M-B)

### Former contributors
* [platysma](https://github.com/platysma)
* [florianL21](https://github.com/florianL21)

## I would like to join this list. How can I help the project?

> Here you could make a call to people who would like to contribute to the project. Below, expose what you expect people to do.

We're currently looking for contributions for the following:

- Bug fixes
- Features
- etc...

For more information, please refer to our [CONTRIBUTING](.vscode/CONTRIBUTING.md) guide.
