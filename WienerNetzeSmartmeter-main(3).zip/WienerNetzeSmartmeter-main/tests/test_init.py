"""Test component setup."""
# from homeassistant.tests.setup import async_setup_component

# from ..custom_components.wnsm.const import DOMAIN # pylint: disable=relative-beyond-top-level


# async def test_async_setup(hass):
#     """Test the component gets setup."""
#     assert await async_setup_component(hass, DOMAIN, {}) is True
