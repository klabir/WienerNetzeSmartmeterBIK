"""Test suite for the Smart Meter package."""
