"""This file contains all constants needed for testing."""

DEMO_USERNAME = "demouser"
DEMO_PASSWORD = "Demouser123"  # noqa
